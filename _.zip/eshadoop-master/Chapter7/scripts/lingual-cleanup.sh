# Execute this only if you have already created schema and you want to start fresh again with lingual
lingual catalog --schema esh --remove;
lingual catalog --provider es --remove;